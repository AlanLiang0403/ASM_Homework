# ASM_Homework
ASM_Homework Record 2015 09 - 2016 01
<ul type=square>
    <li>HW01	Commit 80x86 ASM</li>
    　描述：有兩個數字以NUM[0]、NUM[1]陣列方式存在記憶體中，試計算其加、減乘、除，然後將其「和」、「差」、「積」、「商」、「餘數」分別存回NUM[2]、NUM[3]...。
    <li>HW02	Commit 80x86 ASM</li>
    　描述：撰寫Y=(A+B)*(D-E)/F，A,B,D,E,F,Y分別為記憶體的變數名稱，用一般的有號數十六進位完成。
    <li>HW03	Commit 80x86 ASM</li>
    　描述：有一連串英文大小寫的字串，請將其大寫變小寫，小寫變大寫，特殊符號不變
    <li>HW04	Commit 80x86 ASM</li>
    　描述：有兩個數字以NUM[0]、NUM[1]陣列方式存在記憶體中，試計算其加、減乘、除，然後將其「和」、「差」、「積」、「商」、「餘數」分別存回NUM[2]、NUM[3]...。以unpacked BCD完成
    <li>HW05	Commit 80x86 ASM</li>
    　描述：請計算1到100間3的倍數但扣掉4的倍數之總和<br>
　　1) 不用任何條件高階指令<br>
　　2) 用.WHILE完成<br>
　　3) 用.REPEAT完成<br>
    <li>HW06	Commit 80x86 ASM</li>
    　描述：由鍵盤輸入5*5+8/2-7，然後利用巨集設計加減乘除，經計算後，將結果輸出到螢幕。請加上提示訊息。
    <li>HW07	Commit 80x86 ASM</li>
    　描述：由鍵盤輸入5*5+8/2-7，然後利用副程式設計加減乘除，經計算後，將結果輸出到螢幕。請加上提示訊息。
    <li>Other	Commit 80x86 ASM</li>
    　描述：<br>
    　　1.Proc直接輸出al與ah上16進制的值<br>
    　　2.組合語言輸入兩字密碼，且輸入時呈現 * 隱藏輸入的字<br>
    　　3.輸入mn，再輸入一數字，反序印出數列<br>
</ul>
