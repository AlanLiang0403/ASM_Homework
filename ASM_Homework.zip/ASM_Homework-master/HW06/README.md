# ASM_Homework:
由鍵盤輸入5*5+8/2-7，然後利用巨集設計加減乘除，經計算後，將結果輸出到螢幕。請加上提示訊息。
#DEMO:
<img src="https://github.com/unromanticman/ASM_Homework/blob/master/HW06/demo.png"/>
