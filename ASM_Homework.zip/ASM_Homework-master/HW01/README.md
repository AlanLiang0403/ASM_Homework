# ASM_Homework:
有兩個數字以NUM[0]、NUM[1]陣列方式存在記憶體中，試計算其加、減乘、除，然後將其「和」、「差」、「積」、「商」、「餘數」分別存回NUM[2]、NUM[3]...。
#DEMO:
<img src="https://github.com/unromanticman/ASM_Homework/blob/master/HW01/demo.png"/>
