# ASM_Homework:
請計算1到100間3的倍數但扣掉4的倍數之總和<br>
1) 不用任何條件高階指令<br>
2) 用.WHILE完成<br>
3) 用.REPEAT完成<br>