# ASM_Homework:
撰寫Y=(A+B)*(D-E)/F，A,B,D,E,F,Y分別為記憶體的變數名稱，用一般的有號數十六進位完成。
#DEMO:
<img src="https://github.com/unromanticman/ASM_Homework/blob/master/HW02/demo.png"/>
